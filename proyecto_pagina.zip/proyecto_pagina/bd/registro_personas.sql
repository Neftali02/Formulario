-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1:3306
-- Tiempo de generación: 30-03-2025 a las 20:50:56
-- Versión del servidor: 9.1.0
-- Versión de PHP: 8.3.14

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `registro_personas`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `personas`
--

DROP TABLE IF EXISTS `personas`;
CREATE TABLE IF NOT EXISTS `personas` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nombre_completo` varchar(100) NOT NULL,
  `fecha_nacimiento` date NOT NULL,
  `correo` varchar(100) NOT NULL,
  `contraseña` varchar(255) NOT NULL,
  `fecha_registro` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=22 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Volcado de datos para la tabla `personas`
--

INSERT INTO `personas` (`id`, `nombre_completo`, `fecha_nacimiento`, `correo`, `contraseña`, `fecha_registro`) VALUES
(20, 'lupita4', '2002-12-18', 'elpepe@gmail.com', '$2y$10$9fx2v1i73Zz0rBFlDiBztemFnYdlVl1EN/lU6syDwytJZIK2hMSZ2', '2025-03-29 16:32:43'),
(19, 'lupita1', '2002-12-18', 'elpepe@gmail.com', '$2y$10$gYecgGWr5HXj1zeOzrxmzu2iRtSVPOZ5rPWZtS48Ox16CtloOt/qy', '2025-03-29 16:30:52'),
(18, 'lupita1', '2002-12-18', 'elpepe@gmail.com', '$2y$10$t7BILHBO2X9n/.CHXCo.nuLWU8Qw.OKlF3xqmDqLpoenKFxZ1X9zm', '2025-03-29 16:26:22'),
(17, 'lupita2', '2002-12-18', 'elpepe@gmail.com', '$2y$10$u/UhqwUwqnmzxvchaE2ziOQqFzL18jnYKrkRO.sBAVWVBXnQnTVgW', '2025-03-29 16:19:06'),
(16, 'lupita', '2002-12-18', 'elpepe@gmail.com', '$2y$10$62JBqJA31KNrV8.EpwSDEexnvk/aZUq074uml10kCVmGih6OQBlnm', '2025-03-29 16:13:55'),
(15, 'PEPE', '2025-03-12', 'elpepe@gmail.com', '$2y$10$P2eyng2r8Z6BbbkCB19XvugAII1sOdFzAnyBi7HHynonUKPiyQ5/G', '2025-03-29 16:10:26'),
(14, 'maria', '2025-03-26', 'nepoqq@gmail.com', '$2y$10$KCh..HpAEqxdwkXCIAQRGuhkVE9X0MS4dQF.liTgrbwtxKFYrKSqu', '2025-03-29 16:04:41'),
(13, 'felipo', '2009-03-12', 'talim4777@gmail.com', '$2y$10$BQ418nPjVEDKEcYWeJ.bs.e7jpFYh/k2d.LZT53.oDjcxlTonkfRe', '2025-03-29 16:00:51'),
(12, 'nef', '2010-03-10', 'talim4777@gmail.com', '$2y$10$I9WCK3ToLMYms9qOe6STVuQrOviX3/r7e4gyAwDGDnBzJkkknrN1a', '2025-03-29 16:00:19'),
(11, 'nef', '2010-03-10', 'talim4777@gmail.com', '$2y$10$QCyCMaSIXYNHhcfxznNYcewKBxziIjraVnPRNelGfkiROp6VQYxFS', '2025-03-29 15:56:32'),
(21, 'Pedro', '2009-02-04', 'pedropicapiedra@gmail.com', '$2y$10$2TjUoUmaHM2QynnHs3GuH.x/Pqrwzdw/L0H4QXULSFylWeHERWCoy', '2025-03-29 16:40:32');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
